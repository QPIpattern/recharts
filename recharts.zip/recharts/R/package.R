#' @importFrom magrittr %>%
#' @export %>%
#' @importFrom htmlwidgets JS
#' @export JS
NULL

EChartsVersion = '2.2.7'
