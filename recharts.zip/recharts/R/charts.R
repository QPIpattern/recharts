eLine = function(chart, ...) {

}

eBar = function(chart, ...) {

}

eScatter = function(chart, ...) {

}

eK = function(chart, ...) {

}

ePie = function(chart, ...) {

}

eRadar = function(chart, ...) {

}

eChord = function(chart, ...) {

}

eForce = function(chart, ...) {

}

eMap = function(chart, ...) {

}

eGauge = function(chart, ...) {

}

eFunnel = function(chart, ...) {

}

eEventRiver = function(chart, ...) {

}
